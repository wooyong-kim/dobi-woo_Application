package com.example.myapplication;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

class Joystick {
    private int outerCircleCentarPositionX;
    private int outerCircleCentarPositionY;
    private int innerCircleCentarPositionX;
    private int innerCircleCentarPositionY;

    private int outerCircleRadius;
    private int innerCircleRadius;

    private Paint outerCirclePaint;
    private Paint innerCirclePaint;
    private double joystickCenterToTouchDistance;
    private boolean isPressed;
    private double actuatorX;
    private double actuatorY;

    public Joystick(int CentarPositionX, int CentarPositionY, int outerCircleRadius, int innerCircleRadius) {
        // Outer and inner circle make up the joystick
        outerCircleCentarPositionX = CentarPositionX;
        outerCircleCentarPositionY = CentarPositionY;
        innerCircleCentarPositionX = CentarPositionX;
        innerCircleCentarPositionY = CentarPositionY;

        // Radii of circles
        this.outerCircleRadius = outerCircleRadius;
        this.innerCircleRadius = innerCircleRadius;

        // Paint of circles
        innerCirclePaint = new Paint();
        innerCirclePaint.setColor(Color.GRAY);
        innerCirclePaint.setStyle(Paint.Style.FILL_AND_STROKE);

        outerCirclePaint = new Paint();
        outerCirclePaint.setColor(Color.GRAY);
        outerCirclePaint.setStyle(Paint.Style.FILL_AND_STROKE);
    }

    public void draw(Canvas canvas){
        // Draw outer circle
        canvas.drawCircle(
                outerCircleCentarPositionX,
                outerCircleCentarPositionY,
                outerCircleRadius,
                outerCirclePaint
                );

        // Draw inner circle
        canvas.drawCircle(
                innerCircleCentarPositionX,
                innerCircleCentarPositionY,
                innerCircleRadius,
                innerCirclePaint
        );
    }

    public void update(){
        updateInnerCirclePosition();
    }

    private void updateInnerCirclePosition(){
        innerCircleCentarPositionX = (int) (outerCircleCentarPositionX + actuatorX*outerCircleRadius);
        innerCircleCentarPositionY = (int) (outerCircleCentarPositionY + actuatorY*outerCircleRadius);
    }

    public boolean isPressed(double touchPositinX, double touchPositinY){
        joystickCenterToTouchDistance = Math.sqrt(
                Math.pow(outerCircleCentarPositionX - touchPositinX, 2)
                        + Math.pow(outerCircleCentarPositionY - touchPositinY, 2)
        );
        return joystickCenterToTouchDistance < outerCircleRadius;
    }

    public void setIsPressed(Boolean isPressed){
        this.isPressed = isPressed;
    }

    public boolean getIsPressed(){
        return isPressed;
    }

    public void setActuator(double touchPositinX, double touchPositinY){
        double deltaX = touchPositinX - outerCircleCentarPositionX;
        double deltaY = touchPositinY - outerCircleCentarPositionY;
        double deltaDistance = Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaY, 2));

        if(deltaDistance < outerCircleRadius){
            actuatorX = deltaX/outerCircleRadius;
            actuatorY = deltaY/outerCircleRadius;
        }
        else{
            actuatorX = deltaX/deltaDistance;
            actuatorY = deltaY/deltaDistance;
        }
    }

    public double getActuatorX(){
        return actuatorX;
    }

    public double getActuatorY(){
        return actuatorY;
    }

    public void resetActuaor(){
        actuatorX = 0;
        actuatorY = 0;
    }
}
